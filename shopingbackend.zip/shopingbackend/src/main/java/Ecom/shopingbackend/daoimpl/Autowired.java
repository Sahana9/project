package Ecom.shopingbackend.daoimpl;

public @interface Autowired {

}
